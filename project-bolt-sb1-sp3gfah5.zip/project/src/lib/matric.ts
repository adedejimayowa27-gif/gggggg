/**
 * Validates a matric number: must be a 9-digit number with "812" or "813"
 * at positions 3-5 (the middle three digits).
 *
 * Examples that pass: 230812122, 240812001, 250812421, 260812412
 * The middle three digits (index 3,4,5) must be "812" or "813".
 */
export function validateMatricNumber(matric: string): { valid: boolean; error?: string } {
  const cleaned = matric.trim();

  if (!cleaned) {
    return { valid: false, error: 'Matric number is required.' };
  }

  if (!/^\d+$/.test(cleaned)) {
    return { valid: false, error: 'Matric number must contain only digits.' };
  }

  if (cleaned.length !== 9) {
    return { valid: false, error: 'Matric number must be exactly 9 digits.' };
  }

  const middle = cleaned.substring(3, 6);
  if (middle !== '812' && middle !== '813') {
    return {
      valid: false,
      error: 'Matric number must have 812 or 813 in the middle (positions 4-6).',
    };
  }

  return { valid: true };
}
