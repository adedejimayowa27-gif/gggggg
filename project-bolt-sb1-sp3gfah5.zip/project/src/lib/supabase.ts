import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Profile = {
  id: string;
  full_name: string;
  matric_number: string;
  is_admin: boolean;
  approval_status: 'pending' | 'approved' | 'rejected';
  current_streak: number;
  longest_streak: number;
  created_at: string;
};

export type Document = {
  id: string;
  title: string;
  subject: string;
  content: string;
  created_by: string | null;
  created_at: string;
};

export type QuizQuestion = {
  id: string;
  subject: string;
  question: string;
  options: string[];
  correct_index: number;
  explanation: string;
  created_at: string;
};

export type QuizAttempt = {
  id: string;
  user_id: string;
  question_id: string;
  selected_index: number;
  is_correct: boolean;
  created_at: string;
};

export type UsageLog = {
  id: string;
  user_id: string;
  activity_type: string;
  created_at: string;
};
