import { useState } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import WelcomePage from '@/pages/WelcomePage';
import AuthPage from '@/pages/AuthPage';
import AppShell from '@/pages/AppShell';

type Screen = 'welcome' | 'signin' | 'signup';

function AppContent() {
  const { session, profile, loading } = useAuth();
  const [screen, setScreen] = useState<Screen>('welcome');

  // If user is signed in, show the app shell
  if (session && profile && !loading) {
    return <AppShell />;
  }

  // If loading, show nothing (AppShell handles its own loading)
  if (loading && session) {
    return <AppShell />;
  }

  // Not signed in — show welcome or auth pages
  if (screen === 'signin') {
    return <AuthPage mode="signin" onBack={() => setScreen('welcome')} onSwitch={(m) => setScreen(m)} />;
  }

  if (screen === 'signup') {
    return <AuthPage mode="signup" onBack={() => setScreen('welcome')} onSwitch={(m) => setScreen(m)} />;
  }

  return (
    <WelcomePage
      onSignIn={() => setScreen('signin')}
      onSignUp={() => setScreen('signup')}
    />
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
