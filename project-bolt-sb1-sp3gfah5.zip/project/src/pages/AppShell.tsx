import { useState } from 'react';
import {
  Brain, BookOpen, BarChart3, LogOut, Flame, Trophy,
  Clock, XCircle, Loader2, GraduationCap
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import QuizPage from './QuizPage';
import DocumentsPage from './DocumentsPage';
import AdminDashboard from './AdminDashboard';

type View = 'quiz' | 'documents' | 'admin';

export default function AppShell() {
  const { profile, signOut, loading } = useAuth();
  const [view, setView] = useState<View>('quiz');

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0f0d] flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
      </div>
    );
  }

  // Check approval status
  if (profile && profile.approval_status === 'pending') {
    return <PendingApproval profile={profile} onSignOut={signOut} />;
  }

  if (profile && profile.approval_status === 'rejected') {
    return <RejectedAccess onSignOut={signOut} />;
  }

  const isAdmin = profile?.is_admin ?? false;

  return (
    <div className="min-h-screen bg-[#0a0f0d] text-stone-100">
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-[#0a0f0d]/90 backdrop-blur-md border-b border-stone-800/50">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center">
              <span className="text-stone-900 font-bold text-sm italic" style={{ fontFamily: 'Georgia, serif' }}>MB</span>
            </div>
            <span className="font-semibold text-sm hidden sm:block">Mayorcity B&amp;F AI</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Streak badges */}
            <div className="hidden sm:flex items-center gap-2 mr-2">
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-orange-900/30 border border-orange-800/40">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-xs font-semibold text-orange-300">{profile?.current_streak ?? 0}</span>
              </div>
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-900/30 border border-amber-800/40">
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-xs font-semibold text-amber-300">{profile?.longest_streak ?? 0}</span>
              </div>
            </div>

            {/* User name */}
            <span className="text-xs text-stone-400 hidden md:block max-w-[120px] truncate">
              {profile?.full_name}
            </span>

            <button
              onClick={signOut}
              className="p-2 rounded-lg text-stone-500 hover:text-red-400 hover:bg-red-900/20 transition-colors"
              title="Sign out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Nav tabs */}
        <div className="max-w-5xl mx-auto px-4 pb-2">
          <div className="flex gap-1">
            <NavButton
              active={view === 'quiz'}
              onClick={() => setView('quiz')}
              icon={<Brain className="w-4 h-4" />}
              label="Quiz"
            />
            <NavButton
              active={view === 'documents'}
              onClick={() => setView('documents')}
              icon={<BookOpen className="w-4 h-4" />}
              label="Library"
            />
            {isAdmin && (
              <NavButton
                active={view === 'admin'}
                onClick={() => setView('admin')}
                icon={<BarChart3 className="w-4 h-4" />}
                label="Admin"
              />
            )}
          </div>
        </div>
      </header>

      {/* Content */}
      <main>
        {view === 'quiz' && <QuizPage />}
        {view === 'documents' && <DocumentsPage />}
        {view === 'admin' && isAdmin && <AdminDashboard />}
      </main>
    </div>
  );
}

function NavButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
        active
          ? 'bg-stone-800 text-amber-300'
          : 'text-stone-500 hover:text-stone-300 hover:bg-stone-900/50'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function PendingApproval({
  profile,
  onSignOut,
}: {
  profile: { full_name: string; matric_number: string };
  onSignOut: () => void;
}) {
  return (
    <div className="min-h-screen bg-[#0a0f0d] text-stone-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-5">
          <Clock className="w-8 h-8 text-amber-400" />
        </div>
        <h1 className="text-2xl font-bold mb-3">Awaiting approval</h1>
        <p className="text-stone-400 mb-1">
          Hi {profile.full_name}, your account is pending admin approval.
        </p>
        <p className="text-stone-500 text-sm mb-6">
          Matric: <span className="font-mono">{profile.matric_number}</span>
        </p>
        <p className="text-stone-500 text-sm mb-8">
          You'll get access once an administrator approves your account. Check
          back soon.
        </p>
        <button
          onClick={onSignOut}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-sm font-medium transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign out
        </button>
      </div>
    </div>
  );
}

function RejectedAccess({ onSignOut }: { onSignOut: () => void }) {
  return (
    <div className="min-h-screen bg-[#0a0f0d] text-stone-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-5">
          <XCircle className="w-8 h-8 text-red-400" />
        </div>
        <h1 className="text-2xl font-bold mb-3">Access denied</h1>
        <p className="text-stone-400 mb-8">
          Your account has not been approved. Please contact your administrator
          if you believe this is an error.
        </p>
        <button
          onClick={onSignOut}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-sm font-medium transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign out
        </button>
      </div>
    </div>
  );
}
