import { useState, useEffect } from 'react';
import {
  Users, FileText, BarChart3, CheckCircle2, XCircle, Clock,
  Plus, Loader2, Trash2, TrendingUp, Brain
} from 'lucide-react';
import { supabase, type Profile, type Document } from '@/lib/supabase';

type Tab = 'users' | 'documents' | 'usage';

type UsageStat = {
  user_id: string;
  full_name: string;
  matric_number: string;
  total_activities: number;
  quiz_count: number;
  chat_count: number;
};

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>('users');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [usageStats, setUsageStats] = useState<UsageStat[]>([]);
  const [loading, setLoading] = useState(true);

  // New document form
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocSubject, setNewDocSubject] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  const [savingDoc, setSavingDoc] = useState(false);

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    setLoading(true);
    const [{ data: profilesData }, { data: docsData }, { data: usageData }] = await Promise.all([
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('documents').select('*').order('created_at', { ascending: false }),
      supabase.from('usage_log').select('user_id, activity_type'),
    ]);

    if (profilesData) setProfiles(profilesData as Profile[]);
    if (docsData) setDocuments(docsData as Document[]);

    // Compute usage stats
    if (usageData && profilesData) {
      const statsMap = new Map<string, UsageStat>();
      for (const p of profilesData as Profile[]) {
        statsMap.set(p.id, {
          user_id: p.id,
          full_name: p.full_name,
          matric_number: p.matric_number,
          total_activities: 0,
          quiz_count: 0,
          chat_count: 0,
        });
      }
      for (const log of usageData) {
        const stat = statsMap.get(log.user_id);
        if (stat) {
          stat.total_activities++;
          if (log.activity_type === 'quiz') stat.quiz_count++;
          if (log.activity_type === 'chat') stat.chat_count++;
        }
      }
      const stats = Array.from(statsMap.values())
        .filter((s) => s.total_activities > 0)
        .sort((a, b) => b.total_activities - a.total_activities);
      setUsageStats(stats);
    }

    setLoading(false);
  };

  const updateApproval = async (userId: string, status: 'approved' | 'rejected') => {
    await supabase
      .from('profiles')
      .update({ approval_status: status })
      .eq('id', userId);
    fetchAll();
  };

  const handleAddDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim() || !newDocSubject.trim() || !newDocContent.trim()) return;
    setSavingDoc(true);
    await supabase.from('documents').insert({
      title: newDocTitle.trim(),
      subject: newDocSubject.trim(),
      content: newDocContent.trim(),
    });
    setNewDocTitle('');
    setNewDocSubject('');
    setNewDocContent('');
    setSavingDoc(false);
    fetchAll();
  };

  const deleteDocument = async (id: string) => {
    await supabase.from('documents').delete().eq('id', id);
    fetchAll();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
      </div>
    );
  }

  const pendingCount = profiles.filter((p) => p.approval_status === 'pending').length;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-amber-900/40 flex items-center justify-center text-amber-400">
          <BarChart3 className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          <p className="text-sm text-stone-500">Manage users, documents, and view usage</p>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <StatCard
          icon={<Users className="w-4 h-4" />}
          label="Total Users"
          value={profiles.length}
          color="emerald"
        />
        <StatCard
          icon={<Clock className="w-4 h-4" />}
          label="Pending Approval"
          value={pendingCount}
          color="amber"
        />
        <StatCard
          icon={<FileText className="w-4 h-4" />}
          label="Documents"
          value={documents.length}
          color="blue"
        />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 p-1 rounded-xl bg-stone-900/50 border border-stone-800">
        <TabButton active={tab === 'users'} onClick={() => setTab('users')}>
          User Approvals
          {pendingCount > 0 && (
            <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-amber-500 text-stone-900 text-xs font-bold">
              {pendingCount}
            </span>
          )}
        </TabButton>
        <TabButton active={tab === 'documents'} onClick={() => setTab('documents')}>
          Documents
        </TabButton>
        <TabButton active={tab === 'usage'} onClick={() => setTab('usage')}>
          Usage Leaderboard
        </TabButton>
      </div>

      {/* Users tab */}
      {tab === 'users' && (
        <div className="space-y-3">
          {profiles.length === 0 ? (
            <p className="text-stone-500 text-center py-12 text-sm">No users yet.</p>
          ) : (
            profiles.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between gap-3 p-4 rounded-xl bg-stone-900/40 border border-stone-800"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-semibold text-stone-100 text-sm truncate">{p.full_name}</p>
                    {p.is_admin && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs font-medium">
                        Admin
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-500 font-mono">{p.matric_number}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {p.approval_status === 'pending' && (
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-900/30 border border-amber-800/40 text-amber-300 text-xs">
                      <Clock className="w-3 h-3" /> Pending
                    </span>
                  )}
                  {p.approval_status === 'approved' && (
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-900/30 border border-emerald-800/40 text-emerald-300 text-xs">
                      <CheckCircle2 className="w-3 h-3" /> Approved
                    </span>
                  )}
                  {p.approval_status === 'rejected' && (
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-900/30 border border-red-800/40 text-red-300 text-xs">
                      <XCircle className="w-3 h-3" /> Rejected
                    </span>
                  )}
                  {!p.is_admin && p.approval_status !== 'approved' && (
                    <button
                      onClick={() => updateApproval(p.id, 'approved')}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition-colors"
                    >
                      Approve
                    </button>
                  )}
                  {!p.is_admin && p.approval_status !== 'rejected' && (
                    <button
                      onClick={() => updateApproval(p.id, 'rejected')}
                      className="px-3 py-1.5 rounded-lg bg-red-600/80 hover:bg-red-600 text-white text-xs font-medium transition-colors"
                    >
                      Reject
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Documents tab */}
      {tab === 'documents' && (
        <div>
          {/* Add document form */}
          <form
            onSubmit={handleAddDocument}
            className="rounded-2xl bg-stone-900/50 border border-stone-800 p-5 mb-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <Plus className="w-4 h-4 text-amber-400" />
              <h3 className="font-semibold text-sm">Add reference document</h3>
            </div>
            <div className="space-y-3">
              <input
                type="text"
                value={newDocTitle}
                onChange={(e) => setNewDocTitle(e.target.value)}
                placeholder="Document title"
                className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 transition-colors"
              />
              <input
                type="text"
                value={newDocSubject}
                onChange={(e) => setNewDocSubject(e.target.value)}
                placeholder="Subject (e.g. Digital Banking)"
                className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 transition-colors"
              />
              <textarea
                value={newDocContent}
                onChange={(e) => setNewDocContent(e.target.value)}
                placeholder="Paste the document content here..."
                rows={5}
                className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 transition-colors resize-y"
              />
              <button
                type="submit"
                disabled={savingDoc}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-stone-900 font-semibold text-sm transition-all"
              >
                {savingDoc ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Add document
              </button>
            </div>
          </form>

          {/* Document list */}
          <div className="space-y-3">
            {documents.length === 0 ? (
              <p className="text-stone-500 text-center py-8 text-sm">No documents added yet.</p>
            ) : (
              documents.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-start justify-between gap-3 p-4 rounded-xl bg-stone-900/40 border border-stone-800"
                >
                  <div className="min-w-0 flex-1">
                    <span className="text-xs text-emerald-400 font-medium">{doc.subject}</span>
                    <h4 className="font-semibold text-stone-100 text-sm mt-0.5">{doc.title}</h4>
                    <p className="text-xs text-stone-500 mt-1 line-clamp-2">
                      {doc.content.substring(0, 120)}...
                    </p>
                  </div>
                  <button
                    onClick={() => deleteDocument(doc.id)}
                    className="p-2 rounded-lg text-stone-500 hover:text-red-400 hover:bg-red-900/20 transition-colors flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Usage tab */}
      {tab === 'usage' && (
        <div>
          {usageStats.length === 0 ? (
            <div className="text-center py-12">
              <TrendingUp className="w-10 h-10 text-stone-600 mx-auto mb-3" />
              <p className="text-stone-500 text-sm">No usage activity recorded yet.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {usageStats.map((stat, index) => (
                <div
                  key={stat.user_id}
                  className="flex items-center gap-3 p-4 rounded-xl bg-stone-900/40 border border-stone-800"
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                    index === 0
                      ? 'bg-amber-500 text-stone-900'
                      : index === 1
                      ? 'bg-stone-400 text-stone-900'
                      : index === 2
                      ? 'bg-orange-700 text-stone-100'
                      : 'bg-stone-800 text-stone-400'
                  }`}>
                    {index + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-stone-100 text-sm truncate">{stat.full_name}</p>
                    <p className="text-xs text-stone-500 font-mono">{stat.matric_number}</p>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0 text-xs">
                    <div className="flex items-center gap-1.5 text-emerald-400">
                      <Brain className="w-3.5 h-3.5" />
                      <span className="font-semibold">{stat.quiz_count}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-amber-400">
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span className="font-semibold">{stat.total_activities}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: 'emerald' | 'amber' | 'blue';
}) {
  const colors = {
    emerald: 'bg-emerald-900/30 text-emerald-400 border-emerald-800/40',
    amber: 'bg-amber-900/30 text-amber-400 border-amber-800/40',
    blue: 'bg-blue-900/30 text-blue-400 border-blue-800/40',
  };
  return (
    <div className={`rounded-xl border p-4 ${colors[color]}`}>
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-xs font-medium text-stone-400">{label}</span>
      </div>
      <p className="text-2xl font-bold text-stone-100">{value}</p>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
        active
          ? 'bg-stone-800 text-stone-100'
          : 'text-stone-500 hover:text-stone-300'
      }`}
    >
      {children}
    </button>
  );
}
