import { useState, useEffect } from 'react';
import { BookOpen, FileText, Loader2, Search } from 'lucide-react';
import { supabase, type Document } from '@/lib/supabase';

export default function DocumentsPage() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);

  useEffect(() => {
    const fetchDocs = async () => {
      const { data } = await supabase
        .from('documents')
        .select('*')
        .order('created_at', { ascending: false });
      if (data) setDocuments(data as Document[]);
      setLoading(false);
    };
    fetchDocs();
  }, []);

  const filtered = documents.filter(
    (d) =>
      d.title.toLowerCase().includes(search.toLowerCase()) ||
      d.subject.toLowerCase().includes(search.toLowerCase())
  );

  const subjects = [...new Set(documents.map((d) => d.subject))];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
      </div>
    );
  }

  if (selectedDoc) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8">
        <button
          onClick={() => setSelectedDoc(null)}
          className="text-sm text-stone-400 hover:text-stone-200 mb-4"
        >
          ← Back to documents
        </button>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/30 border border-emerald-800/40 text-emerald-300 text-xs font-medium mb-3">
          {selectedDoc.subject}
        </div>
        <h1 className="text-2xl font-bold mb-6">{selectedDoc.title}</h1>
        <div className="rounded-2xl bg-stone-900/50 border border-stone-800 p-6">
          <p className="text-stone-300 leading-relaxed whitespace-pre-wrap text-sm">
            {selectedDoc.content}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-emerald-900/40 flex items-center justify-center text-emerald-400">
          <BookOpen className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Reference Library</h1>
          <p className="text-sm text-stone-500">
            Study materials added by your admin
          </p>
        </div>
      </div>

      {documents.length === 0 ? (
        <div className="text-center py-20">
          <FileText className="w-12 h-12 text-stone-600 mx-auto mb-4" />
          <p className="text-stone-400">No reference documents have been added yet.</p>
        </div>
      ) : (
        <>
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title or subject..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-900/50 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 transition-colors"
            />
          </div>

          {/* Subject chips */}
          {subjects.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {subjects.map((subject) => (
                <button
                  key={subject}
                  onClick={() => setSearch(subject)}
                  className="px-3 py-1.5 rounded-full bg-stone-800/60 border border-stone-700 text-stone-300 text-xs font-medium hover:border-stone-600 transition-colors"
                >
                  {subject}
                </button>
              ))}
            </div>
          )}

          {/* Document list */}
          <div className="grid gap-3">
            {filtered.map((doc) => (
              <button
                key={doc.id}
                onClick={() => setSelectedDoc(doc)}
                className="text-left p-4 rounded-xl bg-stone-900/40 border border-stone-800 hover:border-stone-700 transition-colors group"
              >
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-stone-800 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-4 h-4 text-stone-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-emerald-400 font-medium">
                        {doc.subject}
                      </span>
                    </div>
                    <h3 className="font-semibold text-stone-100 text-sm group-hover:text-amber-300 transition-colors">
                      {doc.title}
                    </h3>
                    <p className="text-xs text-stone-500 mt-1 line-clamp-2">
                      {doc.content.substring(0, 150)}...
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
