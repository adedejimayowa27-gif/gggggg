import { useState } from 'react';
import { BookOpen, GraduationCap, Sparkles, ArrowRight, Users, Brain, Shield } from 'lucide-react';

type WelcomePageProps = {
  onSignIn: () => void;
  onSignUp: () => void;
};

export default function WelcomePage({ onSignIn, onSignUp }: WelcomePageProps) {
  const [showAbout, setShowAbout] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a0f0d] text-stone-100">
      {/* Hero */}
      <div className="relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-950/40 via-[#0a0f0d] to-stone-950" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-emerald-600/10 rounded-full blur-[120px]" />

        <div className="relative max-w-5xl mx-auto px-6 pt-16 pb-20">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-12">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-900/30">
              <span className="text-stone-900 font-bold text-lg italic" style={{ fontFamily: 'Georgia, serif' }}>MB</span>
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Mayorcity B&amp;F AI</h1>
              <p className="text-xs text-stone-400">Banking &amp; Finance Study Assistant</p>
            </div>
          </div>

          {/* Headline */}
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-900/40 border border-emerald-700/30 text-emerald-300 text-xs font-medium mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              Grounded in CIBN course packs
            </div>
            <h2 className="text-4xl md:text-5xl font-bold leading-[1.1] tracking-tight mb-5">
              Your personal{' '}
              <span className="text-amber-400">banking &amp; finance</span>{' '}
              study companion
            </h2>
            <p className="text-stone-400 text-lg leading-relaxed mb-8 max-w-xl">
              Ask questions, take quizzes, and track your streak — all grounded in
              your own course material. Built for banking &amp; finance students
              by a fellow student.
            </p>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={onSignUp}
                className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-900 font-semibold text-sm transition-all shadow-lg shadow-amber-900/20 hover:shadow-amber-900/40 hover:-translate-y-0.5"
              >
                Get started
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
              <button
                onClick={onSignIn}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-stone-800/60 hover:bg-stone-800 border border-stone-700 text-stone-100 font-semibold text-sm transition-all"
              >
                Sign in
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="relative max-w-5xl mx-auto px-6 py-16 border-t border-stone-800/50">
        <div className="grid md:grid-cols-3 gap-6">
          <FeatureCard
            icon={<Brain className="w-5 h-5" />}
            title="Quiz mode"
            description="Test your knowledge with subject-based quizzes. Get instant feedback and explanations for each answer."
          />
          <FeatureCard
            icon={<Sparkles className="w-5 h-5" />}
            title="Streak tracking"
            description="Build a daily study habit. Answer correctly to grow your streak and beat your personal best."
          />
          <FeatureCard
            icon={<BookOpen className="w-5 h-5" />}
            title="Knowledge base"
            description="Reference documents added by your admin feed the study material — grounded in CIBN course packs."
          />
        </div>
      </div>

      {/* About section */}
      <div className="relative max-w-5xl mx-auto px-6 py-16 border-t border-stone-800/50">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-900/30 border border-amber-700/30 text-amber-300 text-xs font-medium mb-5">
              <Shield className="w-3.5 h-3.5" />
              About
            </div>
            <h3 className="text-2xl font-bold mb-4 tracking-tight">
              About Mayorcity B&amp;F AI
            </h3>
            <p className="text-stone-400 leading-relaxed mb-6">
              A personal banking &amp; finance study assistant, grounded in
              CIBN-centered course packs — Digital Banking, Banking Law &amp;
              Practice, Finance in Global Markets, Risk &amp; Fintech,
              Mathematics of Finance, and Monetary Policy. Answers are drawn
              from the loaded study packs first, with clear general-knowledge
              explanations where a course pack doesn't cover a topic.
            </p>
            <button
              onClick={() => setShowAbout(true)}
              className="text-amber-400 hover:text-amber-300 text-sm font-medium inline-flex items-center gap-1.5"
            >
              Learn about the founder
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="rounded-2xl bg-stone-900/50 border border-stone-800 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-stone-900" />
              </div>
              <div>
                <p className="font-semibold text-stone-100">Adedeji Mayowa</p>
                <p className="text-xs text-stone-500">Founder &amp; Creator</p>
              </div>
            </div>
            <p className="text-sm text-stone-400 leading-relaxed">
              Finance student at Lagos State University (LASU), member of the
              Chartered Institute of Bankers of Nigeria (CIBN), Founder and
              Head Tutor at Determined Minds, mentor with "The Better Version
              of Mayorcity," and Owner &amp; CEO of Mayorcity Emart.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="relative max-w-5xl mx-auto px-6 py-16 border-t border-stone-800/50">
        <div className="rounded-2xl bg-gradient-to-br from-emerald-900/30 to-stone-900 border border-emerald-800/30 p-8 text-center">
          <Users className="w-8 h-8 text-emerald-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">Ready to start studying?</h3>
          <p className="text-stone-400 text-sm mb-6 max-w-md mx-auto">
            Create an account with your matric number and get access to quizzes,
            reference materials, and more.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={onSignUp}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-900 font-semibold text-sm transition-all"
            >
              Create account
            </button>
            <button
              onClick={onSignIn}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-stone-800/60 hover:bg-stone-800 border border-stone-700 text-stone-100 font-semibold text-sm transition-all"
            >
              I already have an account
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative max-w-5xl mx-auto px-6 py-8 border-t border-stone-800/50">
        <p className="text-xs text-stone-600 text-center">
          Mayorcity B&amp;F AI — Built by Adedeji Mayowa. A study companion for
          banking &amp; finance students.
        </p>
      </footer>

      {/* About modal */}
      {showAbout && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={() => setShowAbout(false)}
        >
          <div
            className="max-w-md w-full rounded-2xl bg-stone-900 border border-stone-700 p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-stone-900" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Adedeji Mayowa</h3>
                <p className="text-xs text-stone-500">Founder &amp; Creator</p>
              </div>
            </div>
            <p className="text-sm text-stone-400 leading-relaxed mb-4">
              Adedeji Mayowa is a Finance student at Lagos State University
              (LASU), a member of the Chartered Institute of Bankers of Nigeria
              (CIBN), Founder and Head Tutor at Determined Minds, a mentor with
              "The Better Version of Mayorcity," and Owner &amp; CEO of
              Mayorcity Emart.
            </p>
            <p className="text-sm text-stone-400 leading-relaxed mb-6">
              Mayorcity B&amp;F AI was built to give fellow banking &amp;
              finance students a study companion grounded in their own course
              material.
            </p>
            <button
              onClick={() => setShowAbout(false)}
              className="w-full py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-sm font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-2xl bg-stone-900/40 border border-stone-800 p-6 hover:border-stone-700 transition-colors">
      <div className="w-10 h-10 rounded-lg bg-emerald-900/40 flex items-center justify-center text-emerald-400 mb-4">
        {icon}
      </div>
      <h4 className="font-semibold text-stone-100 mb-2">{title}</h4>
      <p className="text-sm text-stone-400 leading-relaxed">{description}</p>
    </div>
  );
}
