import { useState } from 'react';
import { ArrowLeft, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { validateMatricNumber } from '@/lib/matric';

type AuthPageProps = {
  mode: 'signin' | 'signup';
  onBack: () => void;
  onSwitch: (mode: 'signin' | 'signup') => void;
};

export default function AuthPage({ mode, onBack, onSwitch }: AuthPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [matricNumber, setMatricNumber] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const isSignUp = mode === 'signup';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isSignUp) {
      const matricCheck = validateMatricNumber(matricNumber);
      if (!matricCheck.valid) {
        setError(matricCheck.error || 'Invalid matric number.');
        return;
      }
      if (fullName.trim().length < 2) {
        setError('Please enter your full name.');
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters.');
        return;
      }
    }

    setLoading(true);

    try {
      if (isSignUp) {
        const { error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: fullName.trim(),
              matric_number: matricNumber.trim(),
            },
          },
        });

        if (signUpError) {
          if (signUpError.message.includes('already registered')) {
            setError('An account with this email already exists. Try signing in instead.');
          } else {
            setError(signUpError.message);
          }
          return;
        }

        // Sign in immediately after signup
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (signInError) {
          setError('Account created! Please sign in with your credentials.');
          onSwitch('signin');
          return;
        }
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (signInError) {
          setError('Invalid email or password. Please check your credentials.');
          return;
        }
      }
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0f0d] text-stone-100 flex items-center justify-center p-4">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-emerald-600/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative w-full max-w-md">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200 text-sm mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to home
        </button>

        <div className="rounded-2xl bg-stone-900/60 border border-stone-800 p-8 shadow-2xl">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center">
              <span className="text-stone-900 font-bold italic" style={{ fontFamily: 'Georgia, serif' }}>MB</span>
            </div>
            <div>
              <h1 className="font-semibold tracking-tight">Mayorcity B&amp;F AI</h1>
              <p className="text-xs text-stone-500">
                {isSignUp ? 'Create your account' : 'Welcome back'}
              </p>
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-red-900/30 border border-red-800/40 text-red-300 text-sm mb-5">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <>
                <div>
                  <label className="block text-xs font-medium text-stone-400 mb-1.5">
                    Full name
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Adedeji Mayowa"
                    className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 focus:ring-1 focus:ring-amber-600/30 transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-stone-400 mb-1.5">
                    Matric number
                  </label>
                  <input
                    type="text"
                    value={matricNumber}
                    onChange={(e) => setMatricNumber(e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 230812122"
                    maxLength={9}
                    className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 focus:ring-1 focus:ring-amber-600/30 transition-colors font-mono tracking-wider"
                    required
                  />
                  <p className="text-xs text-stone-600 mt-1.5">
                    Must be 9 digits with 812 or 813 in the middle (e.g. 230812122).
                  </p>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-medium text-stone-400 mb-1.5">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 focus:ring-1 focus:ring-amber-600/30 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-400 mb-1.5">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full px-4 py-2.5 rounded-xl bg-stone-800/60 border border-stone-700 text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-600/50 focus:ring-1 focus:ring-amber-600/30 transition-colors"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed text-stone-900 font-semibold text-sm transition-all"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Please wait...
                </>
              ) : isSignUp ? (
                'Create account'
              ) : (
                'Sign in'
              )}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-stone-500">
            {isSignUp ? (
              <>
                Already have an account?{' '}
                <button
                  onClick={() => onSwitch('signin')}
                  className="text-amber-400 hover:text-amber-300 font-medium"
                >
                  Sign in
                </button>
              </>
            ) : (
              <>
                Don't have an account?{' '}
                <button
                  onClick={() => onSwitch('signup')}
                  className="text-amber-400 hover:text-amber-300 font-medium"
                >
                  Sign up
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
