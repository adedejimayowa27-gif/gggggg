import { useState, useEffect, useCallback } from 'react';
import { Brain, CheckCircle2, XCircle, Flame, Trophy, Loader2, RotateCcw, ArrowRight } from 'lucide-react';
import { supabase, type QuizQuestion } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

export default function QuizPage() {
  const { profile, user, refreshProfile } = useAuth();
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [sessionScore, setSessionScore] = useState(0);
  const [sessionAnswered, setSessionAnswered] = useState(0);
  const [finished, setFinished] = useState(false);

  const loadQuestions = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('quiz_questions')
      .select('*')
      .order('created_at')
      .limit(10);
    if (data) {
      const shuffled = [...data].sort(() => Math.random() - 0.5);
      setQuestions(shuffled);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadQuestions();
  }, [loadQuestions]);

  const logUsage = async (activityType: string) => {
    if (!user) return;
    await supabase.from('usage_log').insert({ activity_type: activityType });
  };

  const handleAnswer = async (index: number) => {
    if (showResult || questions.length === 0) return;
    const question = questions[currentIndex];
    setSelectedAnswer(index);
    setShowResult(true);
    setSessionAnswered((prev) => prev + 1);

    const isCorrect = index === question.correct_index;
    if (isCorrect) {
      setSessionScore((prev) => prev + 1);
    }

    // Record attempt
    await supabase.from('quiz_attempts').insert({
      question_id: question.id,
      selected_index: index,
      is_correct: isCorrect,
    });

    // Update streak
    if (profile) {
      const newStreak = isCorrect ? profile.current_streak + 1 : 0;
      const newLongest = Math.max(profile.longest_streak, newStreak);
      await supabase
        .from('profiles')
        .update({
          current_streak: newStreak,
          longest_streak: newLongest,
        })
        .eq('id', profile.id);
      await refreshProfile();
    }

    await logUsage('quiz');
  };

  const nextQuestion = () => {
    if (currentIndex + 1 >= questions.length) {
      setFinished(true);
      return;
    }
    setCurrentIndex((prev) => prev + 1);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  const restartQuiz = () => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setSessionScore(0);
    setSessionAnswered(0);
    setFinished(false);
    loadQuestions();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="text-center py-20">
        <Brain className="w-12 h-12 text-stone-600 mx-auto mb-4" />
        <p className="text-stone-400">No quiz questions available yet.</p>
      </div>
    );
  }

  if (finished) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="rounded-2xl bg-stone-900/60 border border-stone-800 p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-5">
            <Trophy className="w-8 h-8 text-amber-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Quiz complete!</h2>
          <p className="text-stone-400 mb-6">
            You scored{' '}
            <span className="text-amber-400 font-semibold">{sessionScore}</span> out
            of{' '}
            <span className="text-stone-200 font-semibold">{sessionAnswered}</span>
          </p>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="rounded-xl bg-stone-800/50 border border-stone-700 p-4">
              <div className="flex items-center gap-2 text-orange-400 mb-1">
                <Flame className="w-4 h-4" />
                <span className="text-xs font-medium">Current Streak</span>
              </div>
              <p className="text-2xl font-bold">{profile?.current_streak ?? 0}</p>
            </div>
            <div className="rounded-xl bg-stone-800/50 border border-stone-700 p-4">
              <div className="flex items-center gap-2 text-amber-400 mb-1">
                <Trophy className="w-4 h-4" />
                <span className="text-xs font-medium">Best Streak</span>
              </div>
              <p className="text-2xl font-bold">{profile?.longest_streak ?? 0}</p>
            </div>
          </div>

          <button
            onClick={restartQuiz}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-900 font-semibold text-sm transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            Take another quiz
          </button>
        </div>
      </div>
    );
  }

  const question = questions[currentIndex];

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      {/* Streak bar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-900/30 border border-orange-800/40">
            <Flame className="w-4 h-4 text-orange-400" />
            <span className="text-sm font-semibold text-orange-300">
              {profile?.current_streak ?? 0}
            </span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-900/30 border border-amber-800/40">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-semibold text-amber-300">
              Best: {profile?.longest_streak ?? 0}
            </span>
          </div>
        </div>
        <span className="text-xs text-stone-500">
          Question {currentIndex + 1} of {questions.length}
        </span>
      </div>

      {/* Progress bar */}
      <div className="h-1.5 bg-stone-800 rounded-full mb-8 overflow-hidden">
        <div
          className="h-full bg-amber-500 rounded-full transition-all duration-300"
          style={{ width: `${((currentIndex + (showResult ? 1 : 0)) / questions.length) * 100}%` }}
        />
      </div>

      {/* Subject tag */}
      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/30 border border-emerald-800/40 text-emerald-300 text-xs font-medium mb-4">
        <Brain className="w-3 h-3" />
        {question.subject}
      </div>

      {/* Question */}
      <h2 className="text-xl font-semibold mb-6 leading-relaxed">
        {question.question}
      </h2>

      {/* Options */}
      <div className="space-y-3 mb-6">
        {question.options.map((option, index) => {
          const isSelected = selectedAnswer === index;
          const isCorrect = index === question.correct_index;
          const showCorrect = showResult && isCorrect;
          const showWrong = showResult && isSelected && !isCorrect;

          return (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
              className={`w-full text-left px-4 py-3.5 rounded-xl border text-sm font-medium transition-all flex items-center justify-between gap-3 ${
                showCorrect
                  ? 'bg-emerald-900/30 border-emerald-600 text-emerald-200'
                  : showWrong
                  ? 'bg-red-900/30 border-red-600 text-red-200'
                  : isSelected
                  ? 'bg-amber-900/20 border-amber-600 text-amber-200'
                  : 'bg-stone-900/40 border-stone-700 text-stone-300 hover:border-stone-600 hover:bg-stone-800/60'
              } ${showResult ? 'cursor-default' : 'cursor-pointer'}`}
            >
              <span>{option}</span>
              {showCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />}
              {showWrong && <XCircle className="w-5 h-5 text-red-400 flex-shrink-0" />}
            </button>
          );
        })}
      </div>

      {/* Explanation */}
      {showResult && (
        <div className="rounded-xl bg-stone-900/60 border border-stone-700 p-4 mb-6">
          <p className="text-xs font-medium text-stone-500 mb-1.5">Explanation</p>
          <p className="text-sm text-stone-300 leading-relaxed">{question.explanation}</p>
        </div>
      )}

      {/* Next button */}
      {showResult && (
        <button
          onClick={nextQuestion}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-900 font-semibold text-sm transition-all"
        >
          {currentIndex + 1 >= questions.length ? 'See results' : 'Next question'}
          <ArrowRight className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
